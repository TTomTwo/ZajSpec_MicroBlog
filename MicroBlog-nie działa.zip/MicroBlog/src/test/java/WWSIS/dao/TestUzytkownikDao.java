package WWSIS.dao;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import WWSIS.model.Uzytkownik;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:applicationContext-test.xml"})
@Transactional
@Rollback(true)
public class TestUzytkownikDao {

    @Autowired
    private UzytkownikDao uzytkownikDao;

    private Uzytkownik testUser;

    @Before
    public void setUp() {
        testUser = new Uzytkownik();
        testUser.setLogin("testuser");
        testUser.setEmail("test@example.com");
        testUser.setHaslo("password123");
    }

    @Test
    public void testRegisterUser_ShouldSaveUserToDatabase() {
        // When
        uzytkownikDao.registerUser(testUser);

        // Then
        Uzytkownik retrieved = uzytkownikDao.getUserByLogin("testuser");
        assertNotNull("Użytkownik powinien być zapisany", retrieved);
        assertEquals("Login powinien się zgadzać", "testuser", retrieved.getLogin());
        assertEquals("Email powinien się zgadzać", "test@example.com", retrieved.getEmail());
    }

    @Test
    public void testGetUserByLogin_WhenUserExists_ShouldReturnUser() {
        // Given
        uzytkownikDao.registerUser(testUser);

        // When
        Uzytkownik result = uzytkownikDao.getUserByLogin("testuser");

        // Then
        assertNotNull("Użytkownik powinien być znaleziony", result);
        assertEquals("Login powinien się zgadzać", "testuser", result.getLogin());
    }

    @Test
    public void testGetUserByLogin_WhenUserDoesNotExist_ShouldReturnNull() {
        // When
        Uzytkownik result = uzytkownikDao.getUserByLogin("nieistniejacy_user");

        // Then
        assertNull("Użytkownik nie powinien być znaleziony", result);
    }

    @Test
    public void testRegisterUser_WithEmptyLogin_ShouldStillSave() {
        // Given
        testUser.setLogin("");

        // When
        uzytkownikDao.registerUser(testUser);

        // Then
        Uzytkownik retrieved = uzytkownikDao.getUserByLogin("");
        assertNotNull("Użytkownik z pustym loginem powinien być zapisany", retrieved);
    }

    @Test
    public void testRegisterMultipleUsers_ShouldSaveAll() {
        // Given
        Uzytkownik user1 = new Uzytkownik();
        user1.setLogin("user1");
        user1.setEmail("user1@test.com");
        user1.setHaslo("pass1");

        Uzytkownik user2 = new Uzytkownik();
        user2.setLogin("user2");
        user2.setEmail("user2@test.com");
        user2.setHaslo("pass2");

        // When
        uzytkownikDao.registerUser(user1);
        uzytkownikDao.registerUser(user2);

        // Then
        assertNotNull("User1 powinien być zapisany", uzytkownikDao.getUserByLogin("user1"));
        assertNotNull("User2 powinien być zapisany", uzytkownikDao.getUserByLogin("user2"));
    }
}