package WWSIS.dao;

import static org.junit.Assert.*;

import java.time.LocalDateTime;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import WWSIS.model.Uzytkownik;
import WWSIS.model.Wpis;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:applicationContext-test.xml"})
@Transactional
@Rollback(true)
public class TestWpisDao {

    @Autowired
    private WpisDao wpisDao;

    @Autowired
    private UzytkownikDao uzytkownikDao;

    @Autowired
    private FollowerDao followerDao;

    private Uzytkownik user1;
    private Uzytkownik user2;

    @Before
    public void setUp() {
        // Stwórz użytkowników
        user1 = new Uzytkownik();
        user1.setLogin("user1");
        user1.setEmail("user1@test.com");
        user1.setHaslo("pass1");
        uzytkownikDao.registerUser(user1);

        user2 = new Uzytkownik();
        user2.setLogin("user2");
        user2.setEmail("user2@test.com");
        user2.setHaslo("pass2");
        uzytkownikDao.registerUser(user2);
    }

    @Test
    public void testAddWpis_ShouldSaveWpisToDatabase() {
        // Given
        Wpis wpis = new Wpis();
        wpis.setUzytkownikId(user1.getId());
        wpis.setTresc("Testowy wpis");
        wpis.setDataUtworzenia(LocalDateTime.now());

        // When
        wpisDao.addWpis(wpis);

        // Then
        List<Wpis> wpisy = wpisDao.getWpisyByUserId(user1.getId());
        assertFalse("Lista wpisów nie powinna być pusta", wpisy.isEmpty());
        assertEquals("Treść wpisu powinna się zgadzać", "Testowy wpis", wpisy.get(0).getTresc());
    }

    @Test
    public void testGetWpisyByUserId_ShouldReturnOnlyUserWpisy() {
        // Given
        Wpis wpis1 = new Wpis();
        wpis1.setUzytkownikId(user1.getId());
        wpis1.setTresc("Wpis user1");
        wpis1.setDataUtworzenia(LocalDateTime.now());
        wpisDao.addWpis(wpis1);

        Wpis wpis2 = new Wpis();
        wpis2.setUzytkownikId(user2.getId());
        wpis2.setTresc("Wpis user2");
        wpis2.setDataUtworzenia(LocalDateTime.now());
        wpisDao.addWpis(wpis2);

        // When
        List<Wpis> wpisyUser1 = wpisDao.getWpisyByUserId(user1.getId());

        // Then
        assertEquals("Powinien być tylko 1 wpis", 1, wpisyUser1.size());
        assertEquals("Wpis powinien należeć do user1", "Wpis user1", wpisyUser1.get(0).getTresc());
    }

    @Test
    public void testGetAllWpisy_ShouldReturnAllWpisy() {
        // Given
        Wpis wpis1 = new Wpis();
        wpis1.setUzytkownikId(user1.getId());
        wpis1.setTresc("Wpis 1");
        wpis1.setDataUtworzenia(LocalDateTime.now());
        wpisDao.addWpis(wpis1);

        Wpis wpis2 = new Wpis();
        wpis2.setUzytkownikId(user2.getId());
        wpis2.setTresc("Wpis 2");
        wpis2.setDataUtworzenia(LocalDateTime.now());
        wpisDao.addWpis(wpis2);

        // When
        List<Wpis> allWpisy = wpisDao.getAllWpisy();

        // Then
        assertTrue("Powinno być co najmniej 2 wpisy", allWpisy.size() >= 2);
    }

    @Test
    public void testGetFullTimelineForUser_ShouldIncludeOwnAndFollowedWpisy() {
        // Given - user1 śledzi user2
        followerDao.followUser(user1.getId(), user2.getId());

        Wpis wpisUser1 = new Wpis();
        wpisUser1.setUzytkownikId(user1.getId());
        wpisUser1.setTresc("Wpis user1");
        wpisUser1.setDataUtworzenia(LocalDateTime.now());
        wpisDao.addWpis(wpisUser1);

        Wpis wpisUser2 = new Wpis();
        wpisUser2.setUzytkownikId(user2.getId());
        wpisUser2.setTresc("Wpis user2");
        wpisUser2.setDataUtworzenia(LocalDateTime.now());
        wpisDao.addWpis(wpisUser2);

        // When
        List<Wpis> timeline = wpisDao.getFullTimelineForUser(user1.getId());

        // Then
        assertEquals("Timeline powinien zawierać 2 wpisy", 2, timeline.size());
    }

    @Test
    public void testGetWpisyByUserId_WhenNoWpisy_ShouldReturnEmptyList() {
        // When
        List<Wpis> wpisy = wpisDao.getWpisyByUserId(user1.getId());

        // Then
        assertTrue("Lista powinna być pusta", wpisy.isEmpty());
    }
}