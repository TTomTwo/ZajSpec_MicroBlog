package WWSIS.dao;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import WWSIS.model.Uzytkownik;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:applicationContext-test.xml"})
@Transactional
@Rollback(true)
public class TestFollowerDao {

    @Autowired
    private FollowerDao followerDao;

    @Autowired
    private UzytkownikDao uzytkownikDao;

    // Śledzony
    private Uzytkownik followee;

    // Śledzący
    private Uzytkownik follower;

    @Before
    public void setUp() {
        // Stwórz testowych użytkowników
        followee = new Uzytkownik();
        followee.setLogin("user_followee");
        followee.setEmail("followee@test.com");
        followee.setHaslo("haslo123");
        uzytkownikDao.registerUser(followee);

        follower = new Uzytkownik();
        follower.setLogin("user_follower");
        follower.setEmail("follower@test.com");
        follower.setHaslo("haslo123");
        uzytkownikDao.registerUser(follower);
    }

    @Test
    public void testFollowUser_ShouldAddFollowerRelation() {
        // Given
        assertFalse("Na początku nie powinien śledzić",
                followerDao.isFollowing(follower.getId(), followee.getId()));

        // When
        followerDao.followUser(follower.getId(), followee.getId());

        // Then
        assertTrue("Po dodaniu powinien śledzić",
                followerDao.isFollowing(follower.getId(), followee.getId()));
    }

    @Test
    public void testFollowUser_ShouldNotDuplicateFollowerRelation() {
        // Given
        followerDao.followUser(follower.getId(), followee.getId());

        // When - próba dodania ponownie
        followerDao.followUser(follower.getId(), followee.getId());

        // Then - wciąż powinien śledzić (bez duplikatu)
        assertTrue("Powinien wciąż śledzić bez duplikatu",
                followerDao.isFollowing(follower.getId(), followee.getId()));
    }

    @Test
    public void testUnfollowUser_ShouldRemoveFollowerRelation() {
        // Given
        followerDao.followUser(follower.getId(), followee.getId());
        assertTrue("Powinien śledzić przed usunięciem",
                followerDao.isFollowing(follower.getId(), followee.getId()));

        // When
        followerDao.unfollowUser(follower.getId(), followee.getId());

        // Then
        assertFalse("Po usunięciu nie powinien śledzić",
                followerDao.isFollowing(follower.getId(), followee.getId()));
    }

    @Test
    public void testUnfollowUser_WhenNotFollowing_ShouldNotThrowError() {
        // Given - nie śledzi
        assertFalse("Nie powinien śledzić",
                followerDao.isFollowing(follower.getId(), followee.getId()));

        // When - próba usunięcia nieistniejącej relacji
        followerDao.unfollowUser(follower.getId(), followee.getId());

        // Then - nie powinno być błędu
        assertFalse("Wciąż nie powinien śledzić",
                followerDao.isFollowing(follower.getId(), followee.getId()));
    }

    @Test
    public void testIsFollowing_WhenNotFollowing_ShouldReturnFalse() {
        // When
        boolean result = followerDao.isFollowing(follower.getId(), followee.getId());

        // Then
        assertFalse("Nie powinien śledzić", result);
    }

    @Test
    public void testIsFollowing_WhenFollowing_ShouldReturnTrue() {
        // Given
        followerDao.followUser(follower.getId(), followee.getId());

        // When
        boolean result = followerDao.isFollowing(follower.getId(), followee.getId());

        // Then
        assertTrue("Powinien śledzić", result);
    }
}